import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import engine.SchemaManager;
import model.StructuredFile;

class SchemaManagerTest {

	@Test
	void test() throws IOException {
		SchemaManager schMan = new SchemaManager();
		Path path = Paths.get("src/main/resources/joomlatools__joomla-platform-categories.tsv");
		String fileAlias = schMan.createFileAlias(path.getFileName().toString());
		String fileType = schMan.getFileType(path.getFileName().toString());
		List<StructuredFile> emptyList = new ArrayList<StructuredFile>();
		schMan.updateFileList();
		List<StructuredFile> testList = schMan.getFileList();
		assertNotEquals(emptyList,testList);
		schMan.wipeFileList();
		schMan.wipeRepoFile();
		List<StructuredFile> testList2 = schMan.getFileList();
		List<String[]> emptyRepo = new ArrayList<String[]>();
		schMan.registerFileAsDataSource(fileAlias, path, fileType);
		List<String[]> testRepo = schMan.getRepoFileContents();
		assertNotEquals(emptyList,testList2);
		assertNotEquals(emptyRepo,testRepo);
	}
}
