package example;
import java.awt.Component;

// Packages to import
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileSystemView;
 
public class JTableExamples {
    // frame
    JFrame f;
    JPanel p;
    // Table
    JTable j;
 
    // Constructor
    JTableExamples()
    {
    	System.out.println(FileSystemView.getFileSystemView().getDefaultDirectory());
        // Frame initialization
        f = new JFrame();
 
        // Frame Title
        f.setTitle("JTable Example");
        p = new JPanel();
        f.getContentPane().add(p);
 
        // Data to be displayed in the JTable
        String[][] data = {
            { "Kundan Kumar Jha", "4031", "CSE" },
            { "Anand Jha", "6014", "IT" }
        };
 
        // Column Names
        String[] columnNames = { "Name", "Roll Number", "Department" };
 
        // Initializing the JTable
        j = new JTable(data, columnNames);
        j.setBounds(30, 40, 200, 300);
 
        // adding it to JScrollPane
        JScrollPane sp = new JScrollPane(j);
        f.add(sp);
        // Frame Size
        f.setSize(500, 200);
        // Frame Visible = true
        f.setVisible(true);
        Component[] components = f.getContentPane().getComponents();

        for (Component component : components) {
            System.out.println(component);
        }

        j.revalidate();
        j.repaint();
    }
 
    // Driver  method
    public static void main(String[] args)
    {
        new JTableExamples();
    }
}