package app.simpleClient;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import org.apache.spark.sql.AnalysisException;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import com.opencsv.exceptions.CsvException;

import engine.SchemaManager;

public class SimpleClientApp {
	public static void main(String[] args) throws AnalysisException, IOException, CsvException {
		SparkSession spark = SparkSession
				.builder()
				.appName("A simple client to do things with Spark ")
				.config("spark.master", "local")
				.getOrCreate();
		
		SchemaManager schMan = new SchemaManager();
		boolean stopFlag = false;
		Scanner scanner = new Scanner(System.in);
		while(stopFlag == false) {
			System.out.println("give an integer to do someting.\n1 is used to wipe repo and file list\n"+"2 is used to register a file\n"+"0 is used to exit");
			int code = scanner.nextInt();
			//wipe all the contents of the Repo file and file list.
			if(code == 1) {
				schMan.wipeRepoFile();
				schMan.wipeFileList();
			}
			//register the file
			else if(code == 2) {
				@SuppressWarnings("resource")
				Scanner scanner1 = new Scanner(System.in);
				System.out.println("Enter the File path");
				String filePath = scanner1.next();
				Path path = Paths.get(filePath);
				String fileAlias = schMan.createFileAlias(path.getFileName().toString());
				String fileType = schMan.getFileType(path.getFileName().toString());
				schMan.registerFileAsDataSource(fileAlias, path, fileType);
			}
			//end the loop
			else if(code == 0) {
				scanner.close();
				stopFlag = true;
			}
		}
		//Dataset<Row> df = spark.read().option("delimiter", "\t").option("header", "true").option("inferSchema","true").csv(path.toRealPath().toString());
		//df = spark.read().option("delimiter", ",").option("header", "true").option("inferSchema","true").csv();
		//ignore any front-end mambo jumbo. do it programmatically in the client.
		//try some stuff to see if it works
		spark.stop();
		//etc.
		
	}//end main
}//end class
