package app.frontend;

import java.awt.event.ActionListener;

public class SelectorListener {

	public ActionListener createCommand(String type) {
		if(type.equals("Select")) {
			FileSelector test = new FileSelector();
			return  test;
		}
		return null;
	}
}