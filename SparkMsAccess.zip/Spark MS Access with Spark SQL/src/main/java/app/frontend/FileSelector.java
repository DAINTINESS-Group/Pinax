package app.frontend;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

import java.io.File;

public class FileSelector implements ActionListener {
	
	private File[] files;
	private VisualPinaxApp mainw = VisualPinaxApp.getSingletonView();
	private boolean flag = false;
	private SchemaManagerOLD schemaManager = SchemaManagerOLD.getSingletonView();

	public void filterFile(JFileChooser jfc) {
		FileNameExtensionFilter filter = new FileNameExtensionFilter("tsv,csv Files", "csv", "tsv");
		jfc.setAcceptAllFileFilterUsed(false);
		jfc.setFileFilter(filter);
	}
	
	public void pickFile() throws Exception{
		JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getDefaultDirectory());
		filterFile(jfc);
		jfc.setMultiSelectionEnabled(true);
		int returnValue = jfc.showOpenDialog(mainw.getFrame());
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			files = jfc.getSelectedFiles();
			for(File file : files) {
			    String absolutePath = file.getAbsolutePath(); //gives the absolute path
			    if(schemaManager.checkIfFileIsParsed(absolutePath) == false) {
			    	flag = true;
			    	schemaManager.createMetadataFile(absolutePath);
			    }
			}
		}
		else {
			System.out.println("No files were selected");
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		try {
			pickFile();
			if(flag) {
				schemaManager.loadFiles();
				flag = false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
