package schemamanager;
import java.awt.Component;
import java.awt.Dimension;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

import org.apache.spark.sql.SparkSession;

import scala.Tuple2;
import visualmanager.MSAccess;

import org.apache.spark.sql.AnalysisException;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.commons.io.FilenameUtils;
public class SchemaManager {

	private MSAccess mainw = MSAccess.getSingletonView();
	private static SchemaManager schemaManager;

	public static SchemaManager getSingletonView()
	{
		if(schemaManager == null)
			schemaManager = new SchemaManager();
		return schemaManager;
	}
	
	public SchemaManager() {
		
	}
	
	public String getFileName(String s) {
		File filePath = new File(s);
		String name = filePath.getName();
		name = name.substring(0,name.lastIndexOf("."));
		name = name.replaceAll("[^a-zA-Z0-9]","");
		return name;
	}
	
	public void createMetadataFile(String filePath) {
		File file = new File("src/main/resources/metadata.txt");
		try {
			FileWriter myWriter = new FileWriter(file,true);
			myWriter.write(getFileName(filePath)+","+filePath+","+"0"+"\n");
			myWriter.close();
		} catch (IOException e) {
			e.printStackTrace();	
		}
	}
	
	public void changeFlagStatus(String filePath,File file) throws IOException {
		try (Scanner scanner = new Scanner(file)) {
			StringBuffer inputBuffer = new StringBuffer();
			//now read the file line by line...
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String contents[] = line.split(",");
				if(contents[1].equals(filePath)) {
					inputBuffer.append(contents[0]+","+contents[1]+","+"1");
					inputBuffer.append("\n");
				}
				else {
					inputBuffer.append(line);
					inputBuffer.append("\n");
				}
			}
			clearMetadataFile();
			BufferedWriter bwr = new BufferedWriter(new FileWriter(file));
			//write contents of StringBuffer to a file
			bwr.write(inputBuffer.toString());
			//flush the stream
			bwr.flush();
			//close the stream
			bwr.close();
		}
		catch(FileNotFoundException e) { 
		    //handle this
		}
	}
	
	public boolean checkIfFileIsParsed(String filePath) {
		File file = new File("src/main/resources/metadata.txt");
		try (Scanner scanner = new Scanner(file)) {
			//now read the file line by line...
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String contents[] = line.split(",");
				if(contents[1].equals(filePath)) {
					return true;
				}
			}
		}
		catch(FileNotFoundException e) { 
		    //handle this
		}
		return false;
	}
	
	public void clearMetadataFile() throws FileNotFoundException {
		PrintWriter writer = new PrintWriter("src/main/resources/metadata.txt");
		writer.print("");
		writer.close();
	}
	
	public void createJTables(String filePath, Dataset<Row> df) {
		ArrayList<String[]> dataOfFile = new ArrayList<String[]>();
		String nameOfTable[] = {getFileName(filePath),"Type"};
		for(Tuple2<String, String> element : df.dtypes()) {
			String[] s = {element._1,element._2.substring(0,element._2.length()-4)};
			dataOfFile.add(s);
		}
		String tableData[][] = new String[dataOfFile.size()][];
		for(int i=0;i<dataOfFile.size();i++) {
			tableData[i] = dataOfFile.get(i);
		}
		JPanel panel = new JPanel();
		JTable jt=new JTable(tableData,nameOfTable);
		Dimension d = jt.getPreferredSize();
		jt.setPreferredScrollableViewportSize(d);
		panel.add(jt);
		panel.validate();
		JScrollPane sp=new JScrollPane(jt);    
		panel.add(sp);
		mainw.getLeftPanel().add(panel);
		SwingUtilities.updateComponentTreeUI(mainw.getFrame());
		/*Component[] components = mainw.getLeftPanel().getComponents();

        for (Component component : components) {
            System.out.println(component);
        }*/
	}
	
	public void loadFiles() throws AnalysisException, IOException {
		SparkSession spark = mainw.getSparkSession();
		Dataset<Row> df = null;
		File file = new File("src/main/resources/metadata.txt");
		try (Scanner scanner = new Scanner(file)) {
			//now read the file line by line...
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String contents[] = line.split(",");
				String extention = FilenameUtils.getExtension(contents[1].toString());
				if(extention.equals("csv")) {
					df = spark.read().option("delimiter", ",").option("header", "true").option("inferSchema","true").csv(contents[1]);
				}
				else if(extention.equals("tsv")) {
					df = spark.read().option("delimiter", "\t").option("header", "true").option("inferSchema","true").csv(contents[1]);
				}
				if(checkIfFileIsParsed(contents[1]) && contents[2].equals("0")) {
					createJTables(contents[1],df);
					changeFlagStatus(contents[1],file);
				}
			}
		}
		catch(FileNotFoundException e) { 
		    //handle this
		}
	}
}
